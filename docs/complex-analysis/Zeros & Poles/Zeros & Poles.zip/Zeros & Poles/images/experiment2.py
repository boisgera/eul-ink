#!/usr/bin/env python
"""
Complex-Step Differentiation
"""

# Python 2.7 Standard Library
from __future__ import division
import os

# Third-Party Packages
import numpy as np; np.seterr(all="ignore")
import numpy.linalg as la
import scipy.misc
import matplotlib as mpl; mpl.interactive(True)
import matplotlib.pyplot as pp
import matplotlib.patches as pa

#
# Matplotlib Configuration & Helper Functions
# ------------------------------------------------------------------------------
#
rc = {
    "text.usetex": True,
    "pgf.preamble": [r"\usepackage{amsmath,amsfonts,amssymb}"], 
    "font.family": "serif",
    "font.serif": [],
    "font.sans-serif": [],
    "legend.fontsize": 10, 
    "axes.titlesize":  10,
    "axes.labelsize":  10,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
}
mpl.rcParams.update(rc)

# Use PGF to render PDF with LaTeX fonts of the proper size.
from matplotlib.backends.backend_pgf import FigureCanvasPgf
mpl.backend_bases.register_backend("pdf", FigureCanvasPgf)

# The width of the standard LaTeX document is 345.0 pt.
width_in = 345.0 / 72.0

def save(name, dpi=None):
    options = {}
    if dpi:
        options["dpi"] = dpi
    cwd = os.getcwd()
    root = os.path.dirname(os.path.realpath(__file__))
    os.chdir(root)
    pp.savefig(name + ".pdf", **options)
    pp.savefig(name + ".png", **options)
    pp.savefig(name + ".pgf")
    pp.savefig(name + ".svg")
    os.chdir(cwd)

def set_ratio(ratio, bottom=0.1, top=0.1, left=0.1, right=0.1):
    height_in = (1.0 - left - right)/(1.0 - bottom - top) * width_in / ratio
    pp.gcf().set_size_inches((width_in, height_in))
    pp.gcf().subplots_adjust(bottom=bottom, top=1.0-top, left=left, right=1.0-right)


##/usr/bin/env python

## Python 2.7 Standard Library
#pass

## Third-Party Libraries
#import husl
#import matplotlib as mpl; mpl.interactive(True)
#import matplotlib.pyplot as pp
#import numpy as np
#import PIL
#import PIL.Image

## Local Libraries
#import colormaps as cm

# TODO: "grid" (as complex number),
#       mapping (by the function),
#       then husl mapping,

def grid(xs, ys):
    xs = np.array(xs, dtype=np.complex128)
    ys = np.array(ys, dtype=np.complex128)
    Xs, Ys = np.meshgrid(xs, 1j*ys)
    return Xs + Ys

w, h = 10, 10
z = grid(np.linspace(-1,1,w), np.linspace(-1,1,h))
x = np.real(z)
y = np.imag(z)
fz = z
u = np.real(fz/np.abs(fz))
v = np.imag(fz/np.abs(fz))
pp.quiver(x, y, u, v)
pp.axis("square")
pp.show()

#abs = np.abs(data) / np.amax(np.abs(data))
#norm_angle = (0.5 * np.angle(data) / np.pi) % 1.0
#rgb = cm.viridis(norm_angle)
#rgba = np.clip(np.round(256 * rgb), 0, 255).astype(np.uint8)
#rgb = rgba[:,:,:3]
#image = PIL.Image.fromarray(rgb, "RGB")
##for i in range(m):
##    for j in range(n):
###        H = 360.0 * angle[i,j] / np.pi
###        S = 90#100.0
###        L = 20 + 80.0 * abs[i,j]
###        rgb = np.array(husl.huslp_to_rgb(H, S, L))
##        rgb = 
##        rgb_uint = np.clip(np.round(256 * rgb), 0, 255).astype(np.uint8)
##        colors[i,j,:] = rgb_uint
##image = PIL.Image.fromarray(colors, "RGB")
#image.save("image.png")
##image = image.convert("LA") ;image.save("image.png")
#image.show()

