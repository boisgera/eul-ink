#/usr/bin/env python

# Python 2.7 Standard Library
pass

# Third-Party Libraries
import husl
import matplotlib as mpl; mpl.interactive(True)
import matplotlib.pyplot as pp
import numpy as np
import PIL
import PIL.Image

# Local Libraries
import colormaps as cm

N = 100
Jp = 75 * np.ones(N) # constant lightness
radius = 25
t = np.linspace(0.0, 2.0 * np.pi, N)
ap = radius * np.sin(t)
bp = radius * np.cos(t)
Jpapbp = np.column_stack((Jp, ap, bp))
from colorspacious import cspace_convert

rgb = cspace_convert(Jpapbp, "CAM02-UCS", "sRGB1")
print rgb
from matplotlib.colors import ListedColormap
circular = ListedColormap(rgb, name="circular")

# TODO: "grid" (as complex number),
#       mapping (by the function),
#       then husl mapping,

def grid(xs, ys):
    xs = np.array(xs, dtype=np.complex128)
    ys = np.array(ys, dtype=np.complex128)
    Xs, Ys = np.meshgrid(xs, 1j*ys)
    return Xs + Ys[::-1]

def bw(data):
   m, n = np.shape(data)
   output = 1.0 * np.ones((m, n, 3), dtype=np.float64)
   output[np.real(data) >= 0.5] = np.array([0.0,0.0,0.0])
   return output

w, h = 1024, 1024
z = grid(np.linspace(-2,2,w), np.linspace(-2,2,h))
m, n = np.shape(z)
colors = np.empty((m, n, 3), dtype=np.uint8)

data = (z-1)**2 + z
abs = np.abs(data) / np.amax(np.abs(data))
norm_angle = (0.5 * np.angle(data) / np.pi + 0.5) % 1
#norm_angle = 0.5 * np.ones_like(norm_angle)
rgb = bw(norm_angle)
rgba = np.clip(np.round(256 * rgb), 0, 255).astype(np.uint8)
rgb = rgba[:,:,:3]
image = PIL.Image.fromarray(rgb, "RGB")
#for i in range(m):
#    for j in range(n):
##        H = 360.0 * angle[i,j] / np.pi
##        S = 90#100.0
##        L = 20 + 80.0 * abs[i,j]
##        rgb = np.array(husl.huslp_to_rgb(H, S, L))
#        rgb = 
#        rgb_uint = np.clip(np.round(256 * rgb), 0, 255).astype(np.uint8)
#        colors[i,j,:] = rgb_uint
#image = PIL.Image.fromarray(colors, "RGB")
image.save("image.png")
#image = image.convert("LA") ;image.save("image.png")
image.show()

